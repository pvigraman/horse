<?php
$router->get('','app/controllers/HomeController.php');
$router->get('race','app/controllers/RaceController.php');
$router->get('resetRace','app/controllers/reset-race.php');