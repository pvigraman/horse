<?php

require 'app/views/index.view.php';